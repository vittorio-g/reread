## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----setup--------------------------------------------------------------------
library(reread)

## ----detect-------------------------------------------------------------------
fit <- reread(demo_careless$responses)
fit

## ----scores-------------------------------------------------------------------
head(fit$scores)

## ----truth--------------------------------------------------------------------
table(flagged = fit$flagged, careless = demo_careless$careless)

## ----custom-z-----------------------------------------------------------------
fl <- auto_flag(ensemble_score(demo_careless$responses)$eta, z = 1.5)
fl$n_flagged

## ----manual-------------------------------------------------------------------
reread(demo_careless$responses, prevalence = 0.2)$n_flagged

## ----pieces-------------------------------------------------------------------
es <- ensemble_score(demo_careless$responses)
str(es[c("gate", "profile_info", "signal_strength")])

## ----flag---------------------------------------------------------------------
fl <- auto_flag(es$eta)
c(flagged = fl$n_flagged, prevalence = round(fl$prevalence, 3), status = fl$status)

## ----pt-----------------------------------------------------------------------
pt <- reread(demo_careless$responses, score = "person_total")
c(ensemble = sum(fit$flagged), person_total = pt$n_flagged)

## ----bench, eval = requireNamespace("pROC", quietly = TRUE)-------------------
benchmark_indices(demo_careless$responses, demo_careless$careless)

## ----sim----------------------------------------------------------------------
clean <- simulate_clean(n_factors = 10, items_per_factor = 6, n = 200, seed = 1)
dat   <- inject_careless(clean$data, prevalence = 0.2, seed = 2)
reread(dat$data)$n_flagged

